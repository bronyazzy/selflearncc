"""Language-filtered extraction independent of Qt and clipboard APIs."""
from __future__ import annotations
from dataclasses import dataclass

MAX_COPY_CHARS = 4_000_000

@dataclass(frozen=True)
class CopyPiece:
    text: str
    language: str
    paragraph: str


def combine_pieces(pieces, language: str) -> str:
    """Concatenate inline/sentence fragments; separate only source paragraphs."""
    if language not in {'en', 'zh'}: raise ValueError('复制语言无效。')
    groups = []
    previous = None
    total = 0
    for piece in pieces:
        if piece.language != language or not piece.text: continue
        total += len(piece.text)
        if total > MAX_COPY_CHARS:
            raise ValueError('所选内容超过 400 万字符，请分段复制；没有截断内容或覆盖剪贴板。')
        text = piece.text.replace('\u2029','\n').replace('\u2028','\n').replace('\ufffc','')
        if piece.paragraph != previous:
            groups.append(text); previous = piece.paragraph
        elif groups:
            groups[-1] += text
    return '\n\n'.join(s.strip() for s in groups if s.strip())
