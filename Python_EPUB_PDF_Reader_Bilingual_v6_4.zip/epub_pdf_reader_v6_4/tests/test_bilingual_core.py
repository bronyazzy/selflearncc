import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from lxml import html as LH
from bilingual_alignment import (AlignmentError, AlignmentStore, PairText, prepare_pairs,
    pair_entries,text_of,slice_inline,validate_groups,draft_groups,sentence_ends,
    group_editor_text,parse_editor,DELIMITER)
from bilingual_copy import CopyPiece,combine_pieces
from compatible_layout import compatible_chapter
from epub_core import EpubBook
from publisher_core import PublisherResources

ROOT=Path(__file__).resolve().parents[1]
HTML='''<html><body><p id="p1"><span class="parallel-row"><span class="bi-en" id="en1">Risk is <b>not</b> always loss. A hedge can reduce exposure.</span><span class="bi-zh" id="zh1">风险并不总是损失。对冲可以降低敞口。</span></span></p>
<p><span class="parallel-row"><span class="bi-en">A second paragraph has 3.5% and NAV.</span><span class="bi-zh">第二段保留3.5%和NAV。</span></span></p></body></html>'''

# Original test prose, using the actual structural variants found in the CFA
# samples. Keep the source book text out of the distributable test suite.
BLOCK_HTML='''<html><body>
<div class="pair" id="block-a"><p lang="zh-Hans">信用风险可能上升。对冲可以减少敞口。</p><p lang="en">Credit risk can <b>rise</b>. A hedge may reduce exposure.</p></div>
<div class="pair" id="block-b"><p lang="zh-CN">债券交易价格为99.5。收益率是4%。</p><p lang="en">The bond trades at 99.5. Its yield is 4%.</p></div>
</body></html>'''
TABLE_HTML='''<html><body><table class="parallel"><tbody>
<tr id="row-a" class="text"><td class="en" lang="en"><p class="source-text">Credit risk can <b>rise</b>. A hedge may reduce exposure.</p></td><td class="zh" lang="zh-Hans"><p class="source-text">信用风险可能上升。对冲可以减少敞口。</p></td></tr>
<tr id="row-b" class="text"><td class="en" lang="en"><p class="source-text">The bond trades at 99.5. Its yield is 4%.</p></td><td class="zh" lang="zh-Hans"><p class="source-text">债券交易价格为99.5。收益率是4%。</p></td></tr>
</tbody></table></body></html>'''
EXPECTED_EN='Credit risk can rise. A hedge may reduce exposure.\n\nThe bond trades at 99.5. Its yield is 4%.'


class AutomaticAlignmentTests(unittest.TestCase):
    def test_cfa_block_and_table_prose_are_editable(self):
        for source in (BLOCK_HTML, TABLE_HTML):
            with self.subTest(source=source[:60]):
                entries=pair_entries(LH.fromstring(source))
                self.assertEqual(len(entries),2)
                self.assertTrue(all(pair.editable for _,_,pair in entries))

    def test_automatic_groups_cover_original_text_and_keep_paragraph_identity(self):
        for source in (HTML, BLOCK_HTML, TABLE_HTML):
            root=LH.fromstring(source);original=pair_entries(root)
            _,reviewed,rejected=prepare_pairs(root,auto_groups=True)
            self.assertEqual((reviewed,rejected),(0,0))
            self.assertTrue(root.xpath('//*[@data-mr-auto-grouped]'))
            for _,_,pair in original:
                for lang in ('en','zh'):
                    self.assertEqual(''.join(text_of(u) for u in root.xpath(f'//*[@data-mr-para="{pair.key}"][@data-mr-lang="{lang}"]')),getattr(pair,lang))

    def test_cfa_table_groups_keep_valid_rows_and_anchors(self):
        root=LH.fromstring(TABLE_HTML);prepare_pairs(root,auto_groups=True)
        self.assertEqual(len(root.xpath('//table')),1)
        self.assertEqual(len(root.xpath('//table/tbody/tr')),4)
        self.assertFalse(root.xpath('//table/tbody/*[not(self::tr)]'))
        self.assertFalse(root.xpath('//tr/*[not(self::td or self::th)]'))
        self.assertEqual(len(root.xpath('//*[@id="row-a"]')),1)
        self.assertEqual(len(root.xpath('//*[@id="row-b"]')),1)

    def test_automatic_opt_out_does_not_split(self):
        root=LH.fromstring(BLOCK_HTML);prepare_pairs(root,auto_groups=False)
        self.assertEqual(len(root.xpath('//*[@data-mr-pair]')),2)
        self.assertFalse(root.xpath('//*[@data-mr-auto-grouped]'))

    def test_automatic_groups_do_not_swap_chinese_first_source_columns(self):
        root=LH.fromstring(BLOCK_HTML);prepare_pairs(root,auto_groups=True)
        rows=root.xpath('//*[@data-mr-group]')
        self.assertTrue(rows)
        for row in rows:
            self.assertEqual([n.get('data-mr-lang') for n in row],['zh','en'])

    def test_reviewed_record_has_priority_over_automatic_groups(self):
        root=LH.fromstring(BLOCK_HTML);pair=pair_entries(root)[0][2]
        record={'reviewed':True,'ends':[[len(pair.en),len(pair.zh)]]}
        prepare_pairs(root,{pair.key:record},auto_groups=True)
        self.assertEqual(len(root.xpath(f'//*[@data-mr-para="{pair.key}"]')),2)

    def test_automatic_mismatched_sentence_counts_preserve_whole_pair(self):
        root=LH.fromstring('<div><p lang="en">First. Second.</p><p lang="zh">只有一句。</p></div>')
        before=text_of(root);prepare_pairs(root,auto_groups=True)
        self.assertEqual(text_of(root),before)
        self.assertFalse(root.xpath('//*[@data-mr-auto-grouped]'))

    def test_headings_formulas_images_and_multi_paragraph_cells_stay_intact(self):
        cases=[
            '<div class="pair heading"><p lang="en">First. Second.</p><p lang="zh">第一。第二。</p></div>',
            '<div><p lang="en">First. <math><mi>x</mi></math>Second.</p><p lang="zh">第一。第二。</p></div>',
            '<div><p lang="en">First. <img src="x.png">Second.</p><p lang="zh">第一。第二。</p></div>',
            '<table><tr><td lang="en"><p>First.</p><p>Second.</p></td><td lang="zh"><p>第一。</p><p>第二。</p></td></tr></table>',
            '<table><tr><th lang="en">First. Second.</th><th lang="zh">第一。第二。</th></tr></table>',
        ]
        for source in cases:
            root=LH.fromstring(source);entries=pair_entries(root)
            self.assertFalse(entries[0][2].editable)
            prepare_pairs(root,auto_groups=True)
            self.assertFalse(root.xpath('//*[@data-mr-auto-grouped]'))

    def test_publisher_and_compatible_count_auto_separately_and_keep_table_structure(self):
        from test_bilingual_browser import make_book
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'test.epub';make_book(path,TABLE_HTML)
            with EpubBook(path) as book:
                resources=PublisherResources(book,auto_groups=True)
                doc=LH.fromstring(resources.chapter('OPS/first.xhtml'))
                self.assertEqual(resources.group_counts['OPS/first.xhtml'],(0,0))
                self.assertEqual(resources.auto_group_counts['OPS/first.xhtml'],2)
                self.assertEqual(len(doc.xpath('//table[@data-mr-parallel-table]')),1)
                result=compatible_chapter(book,'OPS/first.xhtml',copy_markers=True,auto_groups=True)
                self.assertEqual((result.grouped,result.auto_grouped,result.pairs),(0,2,4))
                parsed=LH.fromstring(result.html)
                self.assertEqual(len(parsed.xpath('//table')),1)
                self.assertEqual(len(parsed.xpath('//tr')),4)
                self.assertFalse(parsed.xpath('//tr/*[not(self::td or self::th)]'))
                self.assertFalse(parsed.xpath('//table/a|//tbody/a|//tr/a'))
                self.assertEqual(len(parsed.xpath('//td//a[@name="row-a"]')),1)
                self.assertEqual(len(parsed.xpath('//td//a[@name="row-b"]')),1)

def fixture():
    root=LH.fromstring(HTML);node,units,p=pair_entries(root)[0]
    ends=[(p.en.index(' A hedge')+1, p.zh.index('。')+1),(len(p.en),len(p.zh))]
    return root,p,ends

class AlignmentTests(unittest.TestCase):
    def test_text_includes_child_tails(self):
        n=LH.fromstring('<span>a<b>b</b> c<i>d</i> e</span>');self.assertEqual(text_of(n),'ab cd e')
    def test_keys_stable_with_sanitized_host_markers(self):
        a,p,_=fixture();prepare_pairs(a);self.assertEqual(pair_entries(a)[0][2].key,p.key)
    def test_duplicate_text_keys_differ(self):
        root=LH.fromstring('<div>'+HTML.split('<body>')[1].split('</body>')[0]*2+'</div>')
        keys=[x[2].key for x in pair_entries(root)];self.assertEqual(len(keys),len(set(keys)))
    def test_review_required(self):
        _,p,ends=fixture()
        with self.assertRaises(AlignmentError):validate_groups(p,{'ends':ends,'reviewed':False})
    def test_complete_coverage_required(self):
        _,p,ends=fixture()
        with self.assertRaises(AlignmentError):validate_groups(p,{'reviewed':True,'ends':ends[:-1]})
    def test_bad_group_positions(self):
        _,p,ends=fixture()
        for bad in ([[0,1],[len(p.en),len(p.zh)]],[[True,1]],[[-1,1]],[[len(p.en)+1,len(p.zh)]]):
            with self.subTest(bad=bad),self.assertRaises(AlignmentError):validate_groups(p,{'reviewed':True,'ends':bad})
    def test_whitespace_only_groups_rejected(self):
        p=PairText('x','A  B','甲  乙',True)
        with self.assertRaises(AlignmentError):
            validate_groups(p,{'reviewed':True,'ends':[[1,1],[3,3],[4,4]]})
    def test_group_editor_exact_roundtrip(self):
        _,p,ends=fixture();self.assertEqual(parse_editor(p,group_editor_text(p.en,[e[0] for e in ends]),group_editor_text(p.zh,[e[1] for e in ends])),ends)
    def test_editor_rejects_text_change(self):
        _,p,_=fixture()
        with self.assertRaises(AlignmentError):parse_editor(p,p.en+'!',p.zh)
    def test_editor_rejects_different_counts(self):
        _,p,_=fixture()
        with self.assertRaises(AlignmentError):parse_editor(p,p.en[:5]+DELIMITER+p.en[5:],p.zh)
    def test_draft_is_only_ends_not_reviewed_record(self):
        _,p,ends=fixture();self.assertEqual(draft_groups(p),ends)
    def test_different_sentence_counts_no_forced_alignment(self):
        p=PairText('a','First. Second.','仅一句。',True)
        with self.assertRaises(AlignmentError):draft_groups(p)
    def test_abbreviations_and_decimal_not_split(self):
        text='Dr. Lee measured 3.5% in the U.S. market. Next.'
        self.assertEqual(len(sentence_ends(text,'en')),2)
    def test_each_inline_character_split_preserves_source(self):
        root,p,_=fixture();unit=pair_entries(root)[0][1]['en']
        for cut in range(1,len(p.en)):
            a,b=slice_inline(unit,0,cut),slice_inline(unit,cut,len(p.en))
            self.assertEqual(text_of(a)+text_of(b),p.en)
            self.assertEqual(len(a.xpath('//*[@id="en1"]'))+len(b.xpath('//*[@id="en1"]')),1)
    def test_nested_styles_links_and_ids_retained(self):
        unit=LH.fromstring('<span id="x">A <a href="#ref" id="y">B <i>C</i> D</a> E</span>')
        a,b=slice_inline(unit,0,5),slice_inline(unit,5,len(text_of(unit)))
        self.assertEqual(text_of(a)+text_of(b),text_of(unit));self.assertEqual(len(a.xpath('.//a')),1)
        self.assertEqual(b.xpath('.//a')[0].get('href'),'#ref')
    def test_apply_only_reviewed_no_automatic_changes(self):
        root,p,ends=fixture();original=text_of(root)
        _,n,r=prepare_pairs(root,{p.key:{'ends':ends,'reviewed':False}})
        self.assertEqual((n,r),(0,1));self.assertEqual(text_of(root),original)
    def test_apply_regroups_without_losing_language_text(self):
        root,p,ends=fixture();_,n,r=prepare_pairs(root,{p.key:{'ends':ends,'reviewed':True}})
        self.assertEqual((n,r),(1,0))
        for lang,expected in [('en',p.en),('zh',p.zh)]:
            units=root.xpath(f'//*[@data-mr-para="{p.key}"][@data-mr-lang="{lang}"]')
            self.assertEqual(''.join(text_of(u) for u in units),expected)
        self.assertEqual(len(root.xpath('//*[@id="en1"]')),1)
    def test_saved_groups_switch_off(self):
        root,p,ends=fixture();original=text_of(root)
        _,n,_=prepare_pairs(root,{p.key:{'ends':ends,'reviewed':True}},False)
        self.assertEqual(n,0);self.assertEqual(text_of(root),original)
    def test_complex_content_not_split(self):
        root=LH.fromstring('<p><span><span lang="en">A<img src="a.png">B.</span><span lang="zh">甲乙。</span></span></p>')
        self.assertFalse(pair_entries(root)[0][2].editable)
    def test_title_not_split(self):
        root=LH.fromstring('<h1><span><span lang="en">Title.</span><span lang="zh">标题。</span></span></h1>')
        self.assertFalse(pair_entries(root)[0][2].editable)
    def test_store_roundtrip_atomic_and_source_key(self):
        _,p,ends=fixture()
        with tempfile.TemporaryDirectory() as d:
            store=AlignmentStore(Path(d),'a'*64);store.save_pair('OPS/x.xhtml',p,ends)
            loaded=AlignmentStore(Path(d),'a'*64);self.assertEqual(validate_groups(p,loaded.chapter('OPS/x.xhtml')[p.key]),ends)
            self.assertFalse(list(store.path.parent.glob('.alignment-*')))
    def test_store_protects_corrupt_file(self):
        _,p,ends=fixture()
        with tempfile.TemporaryDirectory() as d:
            s=AlignmentStore(Path(d),'a'*64);s.path.parent.mkdir();s.path.write_text('not json')
            s=AlignmentStore(Path(d),'a'*64)
            with self.assertRaises(AlignmentError):s.save_pair('p',p,ends)
            self.assertEqual(s.path.read_text(),'not json')
    def test_store_write_failure_preserves_previous(self):
        _,p,ends=fixture()
        with tempfile.TemporaryDirectory() as d:
            s=AlignmentStore(Path(d),'a'*64);s.save_pair('p',p,ends);raw=s.path.read_bytes()
            with patch('bilingual_alignment.os.replace',side_effect=OSError('disk error')):
                with self.assertRaises(OSError):s.remove_pair('p',p.key)
            self.assertEqual(raw,s.path.read_bytes());self.assertIn(p.key,s.chapter('p'))
    def test_source_digest_mismatch_not_applied(self):
        root,p,ends=fixture();root.xpath('//*[@class="bi-en"]')[0].text='Changed. '
        _,n,_=prepare_pairs(root,{p.key:{'ends':ends,'reviewed':True}});self.assertEqual(n,0)
    def test_native_marker_api_opt_in_only(self):
        with EpubBook(ROOT/'parallel_demo.epub') as book:
            normal=compatible_chapter(book,'OPS/first.xhtml');marked=compatible_chapter(book,'OPS/first.xhtml',copy_markers=True)
            self.assertFalse(normal.copy_units);self.assertTrue(marked.copy_units)
            clean=marked.html
            for spec in marked.copy_units:clean=clean.replace(spec['start'],'').replace(spec['end'],'')
            self.assertEqual(''.join(LH.fromstring(clean).itertext()).split(),''.join(LH.fromstring(normal.html).itertext()).split())
    def test_publisher_and_native_pair_keys_agree(self):
        with EpubBook(ROOT/'parallel_demo.epub') as book:
            root=LH.fromstring(PublisherResources(book).chapter('OPS/first.xhtml'))
            ids={u.get('data-mr-para') for u in root.xpath('//*[@data-mr-lang]')}
            native=compatible_chapter(book,'OPS/first.xhtml',copy_markers=True)
            self.assertEqual(ids,{s['para'] for s in native.copy_units})

class CopyCombineTests(unittest.TestCase):
    def test_keeps_numbers_symbols_and_cjk_inside_english_unit(self):
        self.assertEqual(combine_pieces([CopyPiece('NAV 3.5% “中文”','en','a'),CopyPiece('别栏','zh','a')],'en'),'NAV 3.5% “中文”')
    def test_sentence_groups_recombine_without_empty_lines(self):
        pieces=[CopyPiece('First. ','en','a'),CopyPiece('甲。','zh','a'),CopyPiece('Second.','en','a'),CopyPiece('Next.','en','b')]
        self.assertEqual(combine_pieces(pieces,'en'),'First. Second.\n\nNext.')
    def test_chinese_only(self):
        self.assertEqual(combine_pieces([CopyPiece('English','en','a'),CopyPiece('中文 NAV','zh','a')],'zh'),'中文 NAV')
    def test_empty_matching_selection(self):self.assertEqual(combine_pieces([CopyPiece('E','en','a')],'zh'),'')
    def test_limits_raise_not_truncate(self):
        with patch('bilingual_copy.MAX_COPY_CHARS',5):
            with self.assertRaises(ValueError):combine_pieces([CopyPiece('123456','en','a')],'en')
