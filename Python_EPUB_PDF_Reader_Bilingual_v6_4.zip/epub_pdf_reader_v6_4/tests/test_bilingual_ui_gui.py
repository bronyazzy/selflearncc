"""Exercise the actual default settings, reload and clipboard controls in Qt."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from test_bilingual_browser import make_book
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtTest import QTest
    from PySide6.QtGui import QTextCursor
    from PySide6.QtCore import Qt
    from epub_reader import EnhancedReaderWindow
    from epub_core import StateStore
    QT = True
except (ImportError, OSError, SystemExit):
    QT = False


@unittest.skipUnless(QT, 'PySide6 unavailable; no native UI test executed')
class BilingualControlsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.file = self.root / 'source.epub'
        make_book(self.file)
        with patch.dict(os.environ, {'MODU_COMPATIBLE_EPUB': '1'}):
            self.window = EnhancedReaderWindow(StateStore(self.root / 'state.json'))
        self.window.show()
        self.assertTrue(self.window.open_book(str(self.file)))
        QTest.qWait(80)

    def tearDown(self):
        self.window.close()
        QTest.qWait(40)
        self.tmp.cleanup()

    def test_new_reader_defaults_enable_alignment_copy_lock_and_equal_titles(self):
        self.assertTrue(self.window.auto_groups_action.isChecked())
        self.assertTrue(self.window.copy_language_lock)
        self.assertTrue(self.window.uniform_titles)
        # Two source paragraphs: the first contains two matching sentence groups.
        self.assertEqual(self.window._compatible_pairs, 3)

    def test_toggle_reloads_current_chapter_without_modifying_source(self):
        before = self.file.read_bytes()
        self.window.auto_groups_action.trigger()
        QTest.qWait(70)
        self.assertFalse(self.window.auto_sentence_groups)
        self.assertEqual(self.window._compatible_pairs, 2)
        self.window.auto_groups_action.trigger()
        QTest.qWait(70)
        self.assertEqual(self.window._compatible_pairs, 3)
        self.assertEqual(before, self.file.read_bytes())

    def test_automatic_alignment_preference_persists(self):
        self.window.set_auto_sentence_groups(False)
        self.window.save_state()
        prefs = StateStore(self.root / 'state.json').data['preferences']
        self.assertIs(prefs['auto_sentence_groups'], False)

    def test_ctrl_c_in_boss_mode_copies_contiguous_english_paragraphs(self):
        self.window.set_boss_mode(True)
        QTest.qWait(60)
        browser = self.window.browser
        doc = browser.document()
        start = doc.find('Risk').selectionStart()
        end = doc.find('NAV.').selectionEnd()
        cursor = QTextCursor(doc)
        cursor.setPosition(start)
        cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
        browser.setTextCursor(cursor)
        browser._copy_mouse_range = (start, end)
        browser.setFocus()
        QTest.keyClick(browser, Qt.Key.Key_C, Qt.KeyboardModifier.ControlModifier)
        expected = ('Risk is not always loss. A hedge can reduce exposure.\n\n'
                    'A second paragraph has 3.5% and NAV.')
        self.assertEqual(self.app.clipboard().text(), expected)
        self.assertTrue(all(not w.isVisible() for w in self.window._chrome_widgets()))

